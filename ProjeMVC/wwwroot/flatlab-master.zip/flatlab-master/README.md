# FlatLab - Flat & Responsive Bootstrap Admin Template
Copied from [http://thevectorlab.net/flatlab](http://thevectorlab.net/flatlab/index.html?_blank]
)
